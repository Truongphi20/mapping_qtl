################################################################################
# This script is defined to merge sample_geno, founder_geno, physical_map,
# genetic_map across all chrs and to generate a merged genoprobs for 36 state and 8 state
# Input: output_dir: output directory
#        project_file: a csv file contains 4 columns with column name: prefix, dir, project and investigator. 
#        tag: GigaMUGA or MegaMUGA, tag is used to construct output file name
# Output: merged sample_geno.csv, founder_geno.csv, physical_map.csv, genetic_map.csv
#         merged genoprobs.rds for 36 state and 8 state 
# Run the script: use batch script step3_merge_probs.sh 
#                 or directly run from the command line: Rscript calc_genoprobs.R -o <output_dir> -p <project_file> -t <tag>
################################################################################
options(stringsAsFactors = FALSE)
library(parallel)
library(qtl2)
library(abind)
library(optparse)
library(gtools)

parse_arguments <- function(){
  option_list <- list(
  	make_option(c("-o", "--output_dir"), type = "character", default = NULL, 
  		          help = "Path to outputs", metavar = "character"),
    make_option(c("-p", "--project_file"), type = "character", default = NULL,
                  help = "Path to project file, this file contains prefix, dir, project & investigator", metavar="character"),
    make_option(c("-t", "--tag"), type = "character", default = NULL,
                  help = "GigaMUGA or MegaMUGA, tag is used to construct output file name.", metavar="character")

  );
  opt_parser <- OptionParser(option_list=option_list);
  opt <- parse_args(opt_parser);
  return(opt) 
}

#‘ Merge files
#' @param file_list: a list of file across all chrs   
mergefiles <- function(file_list) {
	mergedlist <- list()
	for (i in 1:length(file_list)) {
		mergedlist[[i]] <- read.csv(file_list[i],header=TRUE, check.names=FALSE)
	}
  merged <- do.call(rbind, mergedlist)
  merged <- merged[!is.na(merged$marker), ]
  merged <- merged[!duplicated(merged$marker), ]
	return(merged)
}

opt <- parse_arguments()
output_dir <- opt$output_dir
project_file <- opt$project_file
tag <- opt$tag
#template to generate gm.json file for merged files cross all chromosomes. 
source("template")

qtl2_dir <- file.path(output_dir, "qtl2")

chr <- c(1:19,"X")
# gather files across all chrs
pmap.files <-  paste0(qtl2_dir, "/chr", chr, "/physical_map.csv")
gmap.files <- paste0(qtl2_dir, "/chr", chr, "/genetic_map.csv")
founder_geno.files <- paste0(qtl2_dir, "/chr", chr, "/founder_geno.csv")
sample.files <- paste0(qtl2_dir, "/chr", chr, "/sample_geno.csv")

# merge files 
pmap.merged <- mergefiles(pmap.files)
pmap.merged <- pmap.merged[order(pmap.merged$chr, pmap.merged$pos), ]
pmap.merged <- pmap.merged[mixedorder(pmap.merged$chr),]
write.csv(file = file.path(qtl2_dir, "physical_map.csv"), pmap.merged, quote=FALSE, row.names=FALSE)

gmap.merged <- mergefiles(gmap.files)
gmap.merged <- gmap.merged[order(gmap.merged$chr, gmap.merged$pos), ]
gmap.merged <- gmap.merged[mixedorder(gmap.merged$chr),]
write.csv(file = file.path(qtl2_dir, "genetic_map.csv"), gmap.merged, quote=FALSE, row.names=FALSE)	

fgeno.merged <- mergefiles(founder_geno.files)
write.csv(file = file.path(qtl2_dir, "founder_geno.csv"), fgeno.merged, quote=FALSE, row.names=FALSE)

samples.merged <- mergefiles(sample.files)
write.csv(file = file.path(qtl2_dir, "sample_geno.csv"), samples.merged, quote=FALSE, row.names=FALSE)

# Write out the json file in each directory.
write(template, file =file.path(qtl2_dir, "gm.json"), sep = "\n")
proj <- read.csv(project_file,stringsAsFactors=FALSE)[1,]
   
# Generate genoprobs
cross <- read_cross2(file = file.path(qtl2_dir, "gm.json"), quiet = FALSE)
n_cores <- detectCores()
probs <- calc_genoprob(cross, cores = n_cores, quiet = FALSE)
aprobs <- genoprob_to_alleleprob(probs, cores = n_cores)

# Save to rds 
saveRDS(probs, file <- file.path(output_dir, paste0(proj$project, "__", tag, "_genoprobs_36state.rds")))
saveRDS(aprobs, file <- file.path(output_dir, paste0(proj$project, "__", tag, "_genoprobs_8state.rds")))
