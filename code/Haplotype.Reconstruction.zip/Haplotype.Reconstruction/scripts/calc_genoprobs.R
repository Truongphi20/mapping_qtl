################################################################################
# The script reconstructs the DO genomes using qtl2 for each chromosome. 
# Input: chr: chromosome number.
#        output_dir: output directory, it contains qtl2/chr*/gm.json that generated in the previous step.
# Output: genoprobs.rds for 8 and 36 states saved under output_dir/HMM/chr*/
# Run the script: use batch script step3_calc_genoprobs.sh 
#                 or run directly from the command line: Rscript calc_genoprobs.R -o <output_dir> -c <chr>
################################################################################
options(stringsAsFactors = FALSE)
library(qtl2)
library(optparse)
library(parallel)

parse_arguments <- function(){
  option_list <- list(
    make_option(c("-c", "--chr"), type = "character", default = NULL, 
                help = "chromosome", metavar = "character"),
  	make_option(c("-o", "--output_dir"), type = "character", default = NULL, 
  		          help = "Output directory", metavar = "character")
  );
  opt_parser <- OptionParser(option_list = option_list);
  opt <- parse_args(opt_parser);
  return(opt) 
}

opt <- parse_arguments()
chr <- opt$chr
output_dir <- opt$output_dir

if (is.null(chr) | is.null(output_dir)) {
    print_help(opt_parser)
    stop("Missing output directory or chromosome.")
}

input_file <- file.path(output_dir, "qtl2", paste0("chr",chr), "gm.json")
output <- file.path(output_dir, "HMM", paste0("chr",chr))

cross <- read_cross2(file = input_file, quiet = FALSE)
probs <- calc_genoprob(cross, cores = detectCores(), quiet = FALSE)
saveRDS(probs, file = file.path(output, "probs_36state.rds"))
aprobs <- genoprob_to_alleleprob(probs, cores = detectCores())
saveRDS(aprobs, file = file.path(output, "probs_8state.rds"))