#!/bin/bash
################################################################################
# This script merges across all chromosomes to generate a set of probs for 36 state and 8 state
# Input: output_dir: output directory
#        working_dir: the source directory of the scripts.
#        project_file: project file contains project's prefix, directory, project name and investigator's name.
#        tag: GigaMUGA or MegaMUGA, tag is used to construct output file name.
################################################################################
#PBS -l nodes=1:ppn=20
#PBS -l walltime=2:00:00
#PBS -l nodes=1:ppn=20
#PBS -l mem=64GB
#PBS -j oe 

module unload R
module load R/3.5.1

echo working_dir $working_dir
echo output_dir $output_dir
echo project_file $project_file
echo tag $tag

cd $working_dir
Rscript merge_probs.R -o $output_dir  -p ${project_file} -t ${tag}