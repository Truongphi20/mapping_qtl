#' Read FinalReport and Sample_Map files and return the allele calls and X and Y intensities.
#' @param path: directory where the files are.
#' @param snps: marker annotation file from UNC.
read_neogen <- function(filepath, snps) {
    report_file <- dir(path = filepath, pattern = "FinalReport.zip$", full.names = TRUE)
    sample_file <- dir(path = filepath, pattern = "Sample_Map.zip$", full.names = TRUE)
    if (length(report_file) == 0 | length(sample_file) == 0) {
        stop(paste("FinalReport or Sample_Map file not found under", filepath))
    }
    report_file_hdr <- unlist(strsplit(report_file, split = "/"))
    report_file_hdr <- report_file_hdr[length(report_file_hdr)]
    header <- read.table(unz(report_file, sub(pattern = "zip$", replacement = "txt", report_file_hdr)), 
                        sep = "\t", skip = 1, nrows = 2)
    # Read Final_report.txt into a dataframe and skip the headers. 
    report <- fread(paste("unzip -cq", report_file),
                        skip = 9, showProgress = TRUE, sep = "\t")
    # Read sample_map.txt into a dataframe.
    samples <- fread(paste0("unzip -cq ",  sample_file))
    colnames(report) <- gsub(" |-", "_", colnames(report))
    # It's critical to make Sample_ID a factor with the levels in the
    # order in the file. If you don't, dplyr helpfully sorts them 
    # alphabetically and messes up the order of the sample IDs.
    geno <- report %>%
      select(Sample_ID, SNP_Name, Allele1___Forward, Allele2___Forward) %>%
      mutate(Sample_ID = factor(Sample_ID, levels = unique(report$Sample_ID))) %>%
      unite(genotype, c("Allele1___Forward", "Allele2___Forward"), sep = "") %>%
      spread(Sample_ID, genotype)
    geno <- geno[match(snps$marker, geno$SNP_Name), ]
    rn <- geno$SNP_Name
    geno <- as.matrix(geno[, -1])
    rownames(geno) <- rn
    # Select X intensity from final_report file.
    x <- report %>% select(Sample_ID, SNP_Name, X) %>%
      mutate(Sample_ID = factor(Sample_ID, levels = unique(report$Sample_ID))) %>%
      spread(Sample_ID, X)
    x <- x[match(snps$marker, x$SNP_Name), ]
    rn <- x$SNP_Name
    x <- as.matrix(x[,-1])
    rownames(x) <- rn
    # Select Y intensity from final_report file. 
    y <- report %>% select(Sample_ID, SNP_Name, Y) %>%
      mutate(Sample_ID = factor(Sample_ID, levels = unique(report$Sample_ID))) %>%
      spread(Sample_ID, Y)
    y <- y[match(snps$marker, y$SNP_Name), ]
    rn <- y$SNP_Name
    y <- as.matrix(y[,-1])
    rownames(y) <- rn 
    run_date <- strsplit(unlist(as.character(header[2, 2])), " ")[[1]][1]
    samples <- cbind(samples, run_date = run_date)
    x <- x[ ,colSums(is.na(x)) < nrow(x), drop=FALSE]
    # Select samples exists in both sample_map and final_reports file. 
    idx <- as.character(intersect(colnames(x), samples$ID))
    x <- x[ ,colnames(x) %in% idx, drop=FALSE]
    y <- y[ ,colnames(y) %in% idx, drop=FALSE]
    geno <- geno[ ,colnames(geno) %in% idx, drop=FALSE]
    samples <- samples[samples$ID %in%idx, drop=FALSE]
    samples <- samples[order(match(samples$ID, idx))]
    cat("x,y,geno,sample dim", dim(x)[2], dim(y)[2],dim(geno)[2],dim(samples)[1],"\n")
    return(list(geno = geno, x = x, y = y, samples = samples))
} 


#‘ Read sample data from projects and create a HDF5 file. 
#' @param projects: project list, each project contains prefix, dir, project and investigator column.
#' @param hdf5_filename: path to the HDF5 file
read_data_and_create_hdf5 <- function(projects, hdf5_filename, snps) {
    #Delete hdf5 file if exists
  if (file.exists(hdf5_filename)) {
    file.remove(hdf5_filename)
    }
  h5createFile(hdf5_filename)
  h5createGroup(hdf5_filename, "G")
  h5createGroup(hdf5_filename, "X")
  h5createGroup(hdf5_filename, "Y")
  h5createGroup(hdf5_filename, "rownames")
  h5createGroup(hdf5_filename, "colnames")
  samples <- NULL
  for(i in 1:nrow(projects)) {
    xyg <- read_neogen(filepath=projects$dir[i], snps = snps)
    xyg$samples <- cbind(xyg$samples, project = projects$project[i],
                        directory = projects$dir[i], prefix = projects$prefix[i],
                        investigator = projects$investigator[i])
    cat("x,y,geno,sample dim", dim(xyg$x)[2], dim(xyg$y)[2],dim(xyg$geno)[2],dim(xyg$samples)[1],"\n")
    samples <- rbind(samples, xyg$samples)
    h5write(xyg$geno, hdf5_filename, paste0("G/", i))
    h5write(xyg$x,    hdf5_filename, paste0("X/", i))
    h5write(xyg$y,    hdf5_filename, paste0("Y/", i))
    h5write(rownames(xyg$geno), hdf5_filename, paste0("rownames/", i))
    h5write(colnames(xyg$geno), hdf5_filename, paste0("colnames/", i))
  }
  H5close()
  return(samples)
}

#' Determine sex.
#' @param x: numeric matrix containing the X intensities. 
#' @param y: numeric matrix containing the Y intensities. 
#' @param markers: data.frame containing marker annotation.
determine_sex <- function(x, y, markers) {
  chrx <- markers$marker[which(markers$chr == "X")]
  chry <- markers$marker[which(markers$chr == "Y")]
  chrx_int <- colMeans(x[chrx,] + y[chrx,], na.rm = T)
  chry_int <- colMeans(x[chry,] + y[chry,], na.rm = T)
  df <- data.frame(x = chrx_int, y = chry_int)
  # Model-based clustering, VVV (ellipsoidal, varying volume, shape, and orientation) model with 2 components.
  # For more info, check https://www.rdocumentation.org/packages/mclust/versions/5.4.6/topics/Mclust
  mc <- Mclust(data = df, G = 2, model = "VVV", prior=priorControl()) 
  # Determine which cluster is females by selecting the cluster with the
  # higher Chr X intensity mean.
  cluster_means <- mc$parameters$mean
  female_cl <- which.max(cluster_means["x",])
  sex <- rep("M", length(mc$classification))
  names(sex) <- colnames(x)
  sex[mc$classification == female_cl] <- "F"
  return(list(sex = sex))
} 

#' Determine sex and get the Chr Y & M haplogroups.
#' @param x: numeric matrix containing the X intensities
#' @param y: numeric matrix containing the Y intensities
#' @param markers: data.frame containing marker annotation.
determine_sex_from_xy_intensities <- function(samples, hdf5_filename, snps) {
  # Open each HDF5 data set, get call rates and Chr X & Y intensities. 
  g <- h5read(hdf5_filename, "G") # genotype
  g <- do.call(cbind, g)
  x <- h5read(hdf5_filename, "X") # X channel intensities
  x <- do.call(cbind, x)
  y <- h5read(hdf5_filename, "Y") # Y channel intensities
  y <- do.call(cbind, y)
  rn <- h5read(hdf5_filename, "rownames")[[1]]  # markers 
  cn <- h5read(hdf5_filename, "colnames")  # samples
  cn <- do.call(c, cn)
  dimnames(g) <- list(rn, cn)
  dimnames(x) <- list(rn, cn)
  dimnames(y) <- list(rn, cn)
  cr <- colMeans(g != "--") # Call rate for each sample avg 0.95
  inferred_sex <- determine_sex(x = x, y = y, markers = snps)$sex
  stopifnot(all(samples$ID == names(inferred_sex)))
  stopifnot(all(samples$ID == names(cr)))
  samples <- cbind(samples, inferred_sex, cr)
  return(samples)
}

#' preprocess snps 
#' @param snps: annotation file generated by Karl Broman https://github.com/kbroman/MUGAarrays/tree/master/UWisc 
process_snps <- function(snps) {
    snps <- snps[snps$unique == TRUE, ]
    snps <- snps[snps$chr %in% c(1:19, "X"), ]
    snps$chr <- sub("^chr", "", snps$chr)  ###remove prefix "chr"
    colnames(snps)[colnames(snps)=="bp_mm10"] <- "pos" 
    colnames(snps)[colnames(snps)=="cM_cox"] <- "cM"
    snps <- snps %>% drop_na(chr, marker) 
    snps$pos <- snps$pos * 1e-6
    rownames(snps) <- snps$marker
    colnames(snps)[1:4] <- c("marker", "chr", "pos", "pos") 
    return(snps)
}

#' Function to convert AA,CC,GG,TT,-- format to ACGTHN format.
#' @param data: sample genotype 
convert_2letter_to1letter <- function(data) {
  new_data <- data
  new_data[new_data == "AA"] <- "A"
  new_data[new_data == "CC"] <- "C"
  new_data[new_data == "GG"] <- "G"
  new_data[new_data == "TT"] <- "T"
  new_data[new_data == "--"] <- "N"
  new_data[nchar(new_data) == 2] <- "H"
  stopifnot(unique(as.vector(new_data)) %in% c("A", "C", "G", "T", "H", "N"))
  return(new_data)
} 

#' Function to convert genotype data to 123 format.
#' @param data: sample genotype 
#' @param founders:  founders genotype 
convert_genotypes <- function(data, founders) {
  stopifnot(nrow(data) == nrow(founders))
  stopifnot(rownames(data) == rownames(founders))
  data <- cbind(data, founders)
  data <- t(data)
  dn <- dimnames(data)
  data <- data.frame(data, stringsAsFactors = F)
  data <- lapply(data, factor, levels = c("A", "C", "G", "T", "H", "N"))
  data <- lapply(data, as.numeric)
  data <- matrix(unlist(data), nrow = length(data[[1]]), ncol = length(data))
  # Record the location of the het calls.
  het <- which(data == 5)
  # Set them to NA temporarily.
  data[het] <- NA
  # Set '6' to NA, indicating no-call.
  data[data == 6] <- NA
  # For each marker, set the lowest allele to 1 and the highest to 3.
  colrng <- apply(data, 2, range, na.rm = T)
  colrng[is.infinite(colrng)] <- NA
  # Set the '1' allele.
  one <- matrix(colrng[1,], nrow = nrow(data), ncol = ncol(data), byrow = T)
  data[data == one] <- 1
  rm(one) 
  # NOTE: At this point, the '2' values are 'C' alleles, not het calls.
  # If there is only one allele, set it to NA in the column range matrix.
  one.allele <- apply(colrng, 2, unique)
  one.allele <- which(sapply(one.allele, length) == 1)
  colrng[,one.allele] <- NA
  # Set the '3' allele.
  three <- matrix(colrng[2,], nrow = nrow(data), ncol = ncol(data), byrow = T)
  data[data == three] <- 3
  rm(three)
  # Set het calls = 2.
  data[het] <- 2
  dimnames(data) <- dn
  data <- t(data)
  # Separate out founders.
  wh_founders <- which(colnames(data) %in% colnames(founders))
  founders <- data[ ,wh_founders]
  data <- data[ ,-wh_founders]
  return(list(data = data, founders = founders))
} 

#' Generate genotype data into 123 format 
#' @param samples_inventory: sample inventory file 
#' @param hdf5_filename: path to the HDF5 file
#' @param founders: founders genotype 
#' @param projects: project list, each project contains prefix, dir, project and investigator column.
generate_genotype_data <- function(hdf5_filename, founders) {
  # Get the number of samples in each group.
  h5_info <- h5ls(hdf5_filename)
  h5_info <- h5_info[h5_info$group == "/G",]
  h5_info <- h5_info[order(as.numeric(h5_info$name)),]
  num_samples <- strsplit(h5_info$dim, " x ")  ##num of samples per project
  n=length(num_samples)
  num_rows <- as.numeric(num_samples[[1]][1])
  num_samples <- c(0, as.numeric(sapply(num_samples, "[", 2)))  
  rn <- h5read(hdf5_filename, "rownames/1")
  geno <- matrix("", nrow = num_rows, ncol = sum(num_samples),
                dimnames = list(rn, rep("", sum(num_samples))))
  for(i in 1:n) {
    G  <- h5read(hdf5_filename, paste0("G/", i))
    cn <- h5read(hdf5_filename, paste0("colnames/", i))
    colnames(G) <- cn
    rng  <- (sum(num_samples[1:i]) + 1):sum(num_samples[1:(i+1)])
    geno[,rng] <- G
    colnames(geno)[rng] <- colnames(G)
  } 
  # Remove samples that should not be included.
  #geno <- geno[ ,sample_inventory$Original.Mouse.ID]
  idx2 <- intersect(colnames(geno), sample_inventory$Original.Mouse.ID)
  geno <- geno[ ,colnames(geno) %in% idx2, drop=FALSE]
  # Keep only the good SNPs.
  geno <- geno[rownames(founders),]
  geno <- convert_2letter_to1letter(data = geno)
  geno_123  <- convert_genotypes(data = geno, founders = founders)
  return(geno_123)
}

#‘ Assemble inventory file. 
#' @param projects: project list, each project contains prefix, dir, project and investigator column.
#' @param samples: sample map matrix. 
#' @param inventory_file: path to the input sample inventory file.
assemble_inventory_file <- function(projects, samples, inventory_file){
    column_names <- c("Project", "Investigator", "Directory", "Original.Mouse.ID", "Unique.Sample.ID",
                "Sex", "Inferred.Sex", "DO.Generation", "Run.Date", "Geneseek.Plate", "Geneseek.Well", "Correct.Mouse.ID",
                "Geneseek.Sample.ID", "Include", "cr")
    inventory <- data.frame(matrix(NA, nrow = 1, ncol = length(column_names),
                                  dimnames = list(NULL, column_names))) 
    # Read in the DO generation data.
    info <- read.csv(inventory_file)
    for (i in 1:nrow(projects)) {
      proj <- strsplit(projects$dir[i], "/")[[1]]
      sample_rows <- which(samples$directory == projects$dir[i])
      local_samples <- samples[sample_rows, ]
      local_samples$Unique.Sample.ID <- as.character(local_samples$ID)
      info$Unique.Sample.ID <- as.character(info$Unique.Sample.ID)
      rows_before <- nrow(local_samples)
      local_samples <- left_join(local_samples, info, by = "Unique.Sample.ID")
      local_samples <- local_samples[!duplicated(local_samples),]
      # Parse out the final directory in the path.
      final_dir <- strsplit(local_samples$directory, "/")
      final_dir <- sapply(final_dir, function(z) { z[length(z)] })
      new_df <- data.frame(Project      = local_samples$project,
                          Investigator = local_samples$investigator,
                          Directory    = final_dir,
                          Original.Mouse.ID = local_samples$ID,
                          Unique.Sample.ID  = paste(final_dir, local_samples$ID, local_samples$Well, sep = "_"),
                          Sex            = local_samples$Sex,
                          Inferred.Sex   = local_samples$inferred_sex,
                          DO.Generation  = local_samples$DO.Generation,
                          Run.Date       = local_samples$run_date,
                          Geneseek.Plate = local_samples$Plate,
                          Geneseek.Well  = local_samples$Well,
                          Correct.Mouse.ID   = local_samples$ID,
                          Geneseek.Sample.ID = local_samples$ID, 
                          Include = !is.na(as.numeric(local_samples$DO.Generation)),
                          cr = local_samples$cr 
      )
      inventory <- rbind(inventory, new_df)
    }
    inventory <- inventory[-1,]   # Remove the empty first row. 
    return(inventory)
  }