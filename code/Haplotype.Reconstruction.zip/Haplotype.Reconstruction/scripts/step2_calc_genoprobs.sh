#!/bin/bash
################################################################################
# This script calculates genoprobs for each chromosome.
# Input: chr: chromosome number.
#        working_dir: the source directory of the scripts. 
#        output_dir: output directory, it contains qtl2/chr*/gm.json that generated in step1.
################################################################################

#PBS -l nodes=1:ppn=20
#PBS -l walltime=2:00:00
#PBS -l nodes=1:ppn=20
#PBS -l mem=64GB
#PBS -j oe 

module unload R
module load R/3.5.1

echo output_dir $output_dir
echo working_dir $working_dir

cd ${working_dir}
Rscript calc_genoprobs.R -o ${output_dir} -c ${chr}